import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { ArrowLeft, Youtube, Upload, CheckCircle, XCircle, Printer, Loader2, RotateCw } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { createWorker } from "tesseract.js";

interface Lesson {
  id: string;
  title: string;
  description: string;
  topic: string;
  content: string;
  youtube_url?: string;
}

interface Exercise {
  id: string;
  question: string;
  answer: string;
  explanation: string;
  difficulty: string;
  order_index: number;
}

interface Submission {
  id: string;
  user_id: string;
  exercise_id: string;
  submission_type: string;
  submission_text?: string;
  submission_url?: string;
  ai_feedback?: string;
  score?: number;
  status: string;
}

const Lesson = () => {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const { toast } = useToast();
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);
  const [submissionText, setSubmissionText] = useState("");
  const [submissionType, setSubmissionType] = useState("text");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [aiProcessing, setAiProcessing] = useState<Record<string, boolean>>({});
  const [ocrProgress, setOcrProgress] = useState(0);
  const [resettingExercises, setResettingExercises] = useState<Record<string, boolean>>({});

  useEffect(() => {
    if (!id) return;

    const fetchLessonData = async () => {
      try {
        // Fetch lesson details
        const { data: lessonData, error: lessonError } = await supabase
          .from("lessons")
          .select("*")
          .eq("id", id)
          .single();

        if (lessonError) throw lessonError;

        // Fetch exercises for this lesson
        const { data: exercisesData, error: exercisesError } = await supabase
          .from("exercises")
          .select("*")
          .eq("lesson_id", id)
          .order("order_index");

        if (exercisesError) throw exercisesError;

        // Fetch user submissions if authenticated
        let submissionsData = [];
        if (user) {
          const { data, error: submissionsError } = await supabase
            .from("submissions")
            .select("*")
            .eq("user_id", user.id)
            .in("exercise_id", exercisesData.map(e => e.id));

          if (submissionsError) throw submissionsError;
          submissionsData = data || [];
        }

        setLesson(lessonData);
        setExercises(exercisesData || []);
        setSubmissions(submissionsData);
      } catch (error) {
        console.error("Error fetching lesson data:", error);
        toast({
          title: "Error",
          description: "Failed to load lesson data",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchLessonData();
  }, [id, user, toast]);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please upload a JPG, PNG, or PDF file",
        variant: "destructive",
      });
      return;
    }

    // Check file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload a file smaller than 10MB",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
  };

  const extractTextFromImage = async (file: File) => {
    const worker = await createWorker('eng', 1, {
      logger: (m) => {
        if (m.status === 'recognizing text') {
          setOcrProgress(Math.round(m.progress * 100));
        }
      },
    });

    try {
      const { data: { text } } = await worker.recognize(file);
      return text;
    } finally {
      await worker.terminate();
      setOcrProgress(0);
    }
  };

  const analyzeMathSubmission = async (exercise: Exercise, submission: string) => {
    try {
      // Using Puter's free API endpoint for math evaluation
      const response = await fetch('https://api.puter.com/v1/math/evaluate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: exercise.question,
          student_answer: submission,
          correct_answer: exercise.answer,
          explanation: exercise.explanation
        })
      });

      if (!response.ok) {
        throw new Error(`API request failed with status ${response.status}`);
      }

      const data = await response.json();
      
      // Fallback if API doesn't return expected data
      if (!data.feedback) {
        const isCorrect = submission.trim().toLowerCase() === exercise.answer.trim().toLowerCase();
        return {
          feedback: isCorrect 
            ? "Your answer is correct! " + exercise.explanation 
            : "Your answer doesn't match the expected solution. The correct answer is: " + exercise.answer,
          score: isCorrect ? 100 : 0
        };
      }

      return {
        feedback: data.feedback,
        score: data.score !== undefined ? data.score : 
              (submission.trim().toLowerCase() === exercise.answer.trim().toLowerCase() ? 100 : 0)
      };
    } catch (error) {
      console.error("Puter AI analysis error:", error);
      // Fallback feedback if API fails
      const isCorrect = submission.trim().toLowerCase() === exercise.answer.trim().toLowerCase();
      return {
        feedback: isCorrect 
          ? "Your answer is correct! " + exercise.explanation 
          : "Your answer doesn't match the expected solution. The correct answer is: " + exercise.answer,
        score: isCorrect ? 100 : 0
      };
    }
  };

  const submitExercise = async (exerciseId: string) => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to submit exercises",
        variant: "destructive",
      });
      return;
    }

    if (submissionType === "text" && !submissionText.trim()) {
      toast({
        title: "Empty submission",
        description: "Please enter your answer",
        variant: "destructive",
      });
      return;
    }

    if ((submissionType === "image" || submissionType === "pdf") && !selectedFile) {
      toast({
        title: "No file selected",
        description: "Please select a file to upload",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    setAiProcessing(prev => ({ ...prev, [exerciseId]: true }));

    try {
      const exercise = exercises.find(e => e.id === exerciseId);
      if (!exercise) throw new Error("Exercise not found");

      let submissionUrl = null;
      let submissionContent = submissionText;

      // Upload file if needed
      if (selectedFile && user) {
        const fileExt = selectedFile.name.split('.').pop();
        const fileName = `${user.id}/${exerciseId}/${Date.now()}.${fileExt}`;
        
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from("submissions")
          .upload(fileName, selectedFile);

        if (uploadError) throw uploadError;
        submissionUrl = uploadData.path;

        // Extract text from image/PDF using OCR
        toast({
          title: "Processing your file",
          description: "Extracting text from your submission...",
        });
        
        submissionContent = await extractTextFromImage(selectedFile);
        
        toast({
          title: "Text extracted",
          description: "Analyzing your math solution...",
        });
      }

      // Get AI feedback before creating the submission
      let aiFeedback = "Automatic checking not available for this submission type";
      let score = 0;

      if (submissionType === "text" || submissionType === "image" || submissionType === "pdf") {
        const analysis = await analyzeMathSubmission(exercise, submissionContent);
        aiFeedback = analysis.feedback;
        score = analysis.score;
      }

      // Create the submission with completed status
      const { data: newSubmission, error: insertError } = await supabase
        .from("submissions")
        .insert({
          user_id: user.id,
          exercise_id: exerciseId,
          submission_type: submissionType,
          submission_text: submissionType === "text" ? submissionText : submissionContent,
          submission_url: submissionUrl,
          ai_feedback: aiFeedback,
          score: score,
          status: "completed"
        })
        .select()
        .single();

      if (insertError) throw insertError;

      toast({
        title: "Success",
        description: "Your submission has been recorded and analyzed!",
      });

      // Reset form
      setSubmissionText("");
      setSelectedFile(null);
      setSubmissionType("text");

      // Refresh submissions
      const { data: newSubmissions } = await supabase
        .from("submissions")
        .select("*")
        .eq("user_id", user.id)
        .in("exercise_id", exercises.map(e => e.id));

      setSubmissions(newSubmissions || []);

    } catch (error) {
      console.error("Error submitting exercise:", error);
      toast({
        title: "Error",
        description: "Failed to submit exercise: " + (error instanceof Error ? error.message : "Unknown error"),
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
      setAiProcessing(prev => ({ ...prev, [exerciseId]: false }));
    }
  };

  const resetExercise = async (exerciseId: string) => {
    if (!user) return;

    setResettingExercises(prev => ({ ...prev, [exerciseId]: true }));

    try {
      // Update the submission status to allow new submission
      const { error } = await supabase
        .from("submissions")
        .update({ status: "retracted" })
        .eq("exercise_id", exerciseId)
        .eq("user_id", user.id);

      if (error) throw error;

      // Remove the submission from local state to show form again
      setSubmissions(prev => prev.filter(s => !(s.exercise_id === exerciseId && s.user_id === user.id)));

      toast({
        title: "Exercise reset",
        description: "You can now redo this exercise",
      });
    } catch (error) {
      console.error("Error resetting exercise:", error);
      toast({
        title: "Error",
        description: "Failed to reset exercise",
        variant: "destructive",
      });
    } finally {
      setResettingExercises(prev => ({ ...prev, [exerciseId]: false }));
    }
  };

  const printPage = () => {
    window.print();
  };

  const getSubmissionForExercise = (exerciseId: string) => {
    return submissions.find(s => s.exercise_id === exerciseId);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty.toLowerCase()) {
      case "easy": return "bg-green-100 text-green-800";
      case "medium": return "bg-yellow-100 text-yellow-800";
      case "hard": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-pulse text-primary mb-4">Loading lesson...</div>
        </div>
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Lesson not found</h2>
          <Link to="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card print:hidden">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link to="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <h1 className="text-xl font-bold">{lesson.title}</h1>
          </div>
          <Button variant="outline" onClick={printPage}>
            <Printer className="w-4 h-4 mr-2" />
            Print
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Lesson Content */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="text-2xl mb-2">{lesson.title}</CardTitle>
                <Badge className="mb-4">{lesson.topic}</Badge>
                <CardDescription className="text-base">
                  {lesson.description}
                </CardDescription>
              </div>
              {lesson.youtube_url && (
                <a 
                  href={lesson.youtube_url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="print:hidden"
                >
                  <Button variant="outline">
                    <Youtube className="w-4 h-4 mr-2 text-red-500" />
                    Watch Video
                  </Button>
                </a>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="prose max-w-none">
              <p className="text-lg leading-relaxed">{lesson.content}</p>
            </div>
          </CardContent>
        </Card>

        {/* Exercises */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold">Practice Exercises</h2>
          
          {exercises.map((exercise, index) => {
            const submission = getSubmissionForExercise(exercise.id);
            const isProcessing = aiProcessing[exercise.id];
            const isResetting = resettingExercises[exercise.id];
            
            return (
              <Card key={exercise.id} className="break-inside-avoid">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">
                        Exercise {index + 1}
                      </CardTitle>
                      <Badge className={`text-xs ${getDifficultyColor(exercise.difficulty)}`}>
                        {exercise.difficulty}
                      </Badge>
                    </div>
                    {submission && (
                      <div className="flex items-center space-x-2">
                        {submission.status === "completed" ? (
                          <CheckCircle className="w-5 h-5 text-green-500" />
                        ) : submission.status === "pending" || isProcessing ? (
                          <Loader2 className="w-5 h-5 text-yellow-500 animate-spin" />
                        ) : (
                          <div className="w-5 h-5 border-2 border-yellow-500 border-t-transparent rounded-full animate-spin" />
                        )}
                        <span className="text-sm text-muted-foreground capitalize">
                          {submission.status || "pending"}
                        </span>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-lg font-medium">{exercise.question}</p>
                    
                    {/* Show answer and explanation in print mode */}
                    <div className="hidden print:block border-t pt-4">
                      <p className="font-medium">Answer: {exercise.answer}</p>
                      <p className="text-sm text-muted-foreground mt-2">
                        {exercise.explanation}
                      </p>
                    </div>
                    
                    {/* Submission form - hidden in print */}
                    {user && (!submission || submission.status === "retracted") && (
                      <div className="print:hidden space-y-4 border-t pt-4">
                        <Label>Submit your answer:</Label>
                        
                        <RadioGroup 
                          value={submissionType} 
                          onValueChange={setSubmissionType}
                          className="flex space-x-6"
                        >
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="text" id="text" />
                            <Label htmlFor="text">Text Answer</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="image" id="image" />
                            <Label htmlFor="image">Upload Image</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <RadioGroupItem value="pdf" id="pdf" />
                            <Label htmlFor="pdf">Upload PDF</Label>
                          </div>
                        </RadioGroup>

                        {submissionType === "text" && (
                          <Textarea
                            placeholder="Enter your answer here..."
                            value={submissionText}
                            onChange={(e) => setSubmissionText(e.target.value)}
                            rows={4}
                          />
                        )}

                        {(submissionType === "image" || submissionType === "pdf") && (
                          <div className="space-y-2">
                            <Input
                              type="file"
                              accept={submissionType === "image" ? "image/*" : ".pdf"}
                              onChange={handleFileUpload}
                            />
                            {selectedFile && (
                              <p className="text-sm text-muted-foreground">
                                Selected: {selectedFile.name}
                              </p>
                            )}
                            {ocrProgress > 0 && (
                              <div className="space-y-1">
                                <div className="flex items-center justify-between">
                                  <span className="text-xs">Extracting text...</span>
                                  <span className="text-xs">{ocrProgress}%</span>
                                </div>
                                <div className="w-full bg-gray-200 rounded-full h-1.5">
                                  <div 
                                    className="bg-blue-500 h-1.5 rounded-full" 
                                    style={{ width: `${ocrProgress}%` }}
                                  ></div>
                                </div>
                              </div>
                            )}
                          </div>
                        )}

                        <Button 
                          onClick={() => submitExercise(exercise.id)}
                          disabled={submitting || isProcessing || (submissionType !== "text" && !selectedFile)}
                          className="w-full sm:w-auto"
                        >
                          {submitting || isProcessing ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              {isProcessing ? "Analyzing..." : "Submitting..."}
                            </>
                          ) : (
                            <>
                              <Upload className="w-4 h-4 mr-2" />
                              Submit Answer
                            </>
                          )}
                        </Button>
                      </div>
                    )}

                    {/* Show submission feedback and redo button */}
                    {submission && submission.status !== "retracted" && (submission.ai_feedback || submission.status === "pending") && (
                      <div className="print:hidden space-y-4">
                        <div className="bg-muted p-4 rounded-lg">
                          <h4 className="font-medium mb-2">Feedback:</h4>
                          {submission.status === "pending" ? (
                            <div className="flex items-center space-x-2">
                              <Loader2 className="w-4 h-4 animate-spin" />
                              <span>Analyzing your submission...</span>
                            </div>
                          ) : (
                            <>
                              <p className="text-sm">{submission.ai_feedback}</p>
                              {submission.score !== null && submission.score !== undefined && (
                                <div className="mt-2">
                                  <div className="flex items-center justify-between mb-1">
                                    <span className="text-sm font-medium">Score:</span>
                                    <span className="text-sm font-medium">{submission.score}/100</span>
                                  </div>
                                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                                    <div 
                                      className={`h-2.5 rounded-full ${
                                        submission.score >= 80 ? 'bg-green-500' :
                                        submission.score >= 50 ? 'bg-yellow-500' : 'bg-red-500'
                                      }`} 
                                      style={{ width: `${submission.score}%` }}
                                    ></div>
                                  </div>
                                </div>
                              )}
                            </>
                          )}
                        </div>
                        
                        {/* Redo Exercise Button - Only shown when not processing */}
                        {submission.status !== "pending" && (
                          <Button 
                            variant="outline" 
                            onClick={() => resetExercise(exercise.id)}
                            disabled={isResetting}
                            className="w-full"
                          >
                            {isResetting ? (
                              <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Resetting...
                              </>
                            ) : (
                              <>
                                <RotateCw className="w-4 h-4 mr-2" />
                                Redo This Exercise
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </main>
    </div>
  );
};

export default Lesson;
