// Update this page (the content is just a fallback if you fail to update the page)

import { useAuth } from "@/hooks/useAuth";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Calculator, Trophy, Youtube, LogOut } from "lucide-react";
import { Link } from "react-router-dom";

interface Lesson {
  id: string;
  title: string;
  description: string;
  topic: string;
  youtube_url?: string;
  order_index: number;
}

interface UserProgress {
  lesson_id: string;
  progress_percentage: number;
  completed_at?: string;
}

const Index = () => {
  const { user, loading, signOut } = useAuth();
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [userProgress, setUserProgress] = useState<UserProgress[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      return;
    }

    const fetchData = async () => {
      try {
        // Fetch lessons
        const { data: lessonsData, error: lessonsError } = await supabase
          .from("lessons")
          .select("*")
          .order("order_index");

        if (lessonsError) throw lessonsError;

        // Fetch user progress if authenticated
        let progressData = [];
        if (user) {
          const { data, error: progressError } = await supabase
            .from("user_progress")
            .select("*")
            .eq("user_id", user.id);

          if (progressError) throw progressError;
          progressData = data || [];
        }

        setLessons(lessonsData || []);
        setUserProgress(progressData);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoadingData(false);
      }
    };

    fetchData();
  }, [user, loading]);

  const getProgressForLesson = (lessonId: string) => {
    const progress = userProgress.find(p => p.lesson_id === lessonId);
    return progress?.progress_percentage || 0;
  };

  const getTopicColor = (topic: string) => {
    switch (topic.toLowerCase()) {
      case "algebra": return "bg-blue-100 text-blue-800";
      case "geometry": return "bg-green-100 text-green-800";
      case "number theory": return "bg-purple-100 text-purple-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Calculator className="w-12 h-12 animate-pulse text-primary mx-auto mb-4" />
          <p>Loading NiatiMath...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-primary/10 to-secondary/10 p-4">
        <div className="text-center max-w-4xl mx-auto">
          <div className="flex items-center justify-center mb-8">
            <Calculator className="w-16 h-16 text-primary mr-4" />
            <h1 className="text-5xl font-bold text-primary">NiatiMath</h1>
          </div>
          <h2 className="text-3xl font-semibold mb-4 text-foreground">
            Grade 8 Mathematics Tutor
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Master Grade 8 mathematics with interactive lessons, AI-powered feedback, 
            and personalized learning designed for South African curriculum.
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="text-center">
              <CardContent className="pt-6">
                <BookOpen className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Interactive Lessons</h3>
                <p className="text-sm text-muted-foreground">
                  Step-by-step tutorials with YouTube videos
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="pt-6">
                <Trophy className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">AI Feedback</h3>
                <p className="text-sm text-muted-foreground">
                  Upload your work for instant AI-powered corrections
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center">
              <CardContent className="pt-6">
                <Calculator className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Practice Exercises</h3>
                <p className="text-sm text-muted-foreground">
                  Hundreds of practice problems with detailed explanations
                </p>
              </CardContent>
            </Card>
          </div>

          <Link to="/auth">
            <Button size="lg" className="text-lg px-8 py-3">
              Get Started - Sign Up Free
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Calculator className="w-8 h-8 text-primary" />
            <h1 className="text-2xl font-bold text-primary">NiatiMath</h1>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">
              Welcome back!
            </span>
            <Button variant="outline" onClick={signOut}>
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Grade 8 Mathematics</h2>
          <p className="text-muted-foreground">
            Choose a lesson to start learning. Track your progress and improve your skills!
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {lessons.map((lesson) => {
            const progress = getProgressForLesson(lesson.id);
            return (
              <Card key={lesson.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg mb-2">{lesson.title}</CardTitle>
                      <Badge className={`text-xs ${getTopicColor(lesson.topic)}`}>
                        {lesson.topic}
                      </Badge>
                    </div>
                    {lesson.youtube_url && (
                      <Youtube className="w-5 h-5 text-red-500 ml-2" />
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="mb-4">
                    {lesson.description}
                  </CardDescription>
                  
                  {progress > 0 && (
                    <div className="mb-4">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Progress</span>
                        <span>{progress}%</span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div 
                          className="bg-primary h-2 rounded-full transition-all duration-300" 
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>
                  )}
                  
                  <Link to={`/lesson/${lesson.id}`}>
                    <Button className="w-full">
                      {progress > 0 ? "Continue" : "Start"} Lesson
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </main>
    </div>
  );
};

export default Index;
