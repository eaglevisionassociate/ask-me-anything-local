-- Create profiles table for user information
CREATE TABLE public.profiles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  grade INTEGER DEFAULT 8,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- Create lessons table for Grade 8 math curriculum
CREATE TABLE public.lessons (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  topic TEXT NOT NULL,
  grade INTEGER NOT NULL DEFAULT 8,
  youtube_url TEXT,
  content TEXT,
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create exercises table for practice problems
CREATE TABLE public.exercises (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  lesson_id UUID NOT NULL REFERENCES public.lessons(id) ON DELETE CASCADE,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  explanation TEXT,
  difficulty TEXT CHECK (difficulty IN ('easy', 'medium', 'hard')) DEFAULT 'medium',
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create submissions table for student work
CREATE TABLE public.submissions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  exercise_id UUID NOT NULL REFERENCES public.exercises(id) ON DELETE CASCADE,
  submission_type TEXT CHECK (submission_type IN ('text', 'image', 'pdf')) NOT NULL,
  submission_url TEXT,
  submission_text TEXT,
  ai_feedback TEXT,
  score INTEGER CHECK (score >= 0 AND score <= 100),
  status TEXT CHECK (status IN ('pending', 'reviewed', 'corrected')) DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create user progress tracking
CREATE TABLE public.user_progress (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  lesson_id UUID NOT NULL REFERENCES public.lessons(id) ON DELETE CASCADE,
  completed_at TIMESTAMP WITH TIME ZONE,
  progress_percentage INTEGER DEFAULT 0 CHECK (progress_percentage >= 0 AND progress_percentage <= 100),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, lesson_id)
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exercises ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_progress ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Users can view their own profile"
ON public.profiles FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own profile"
ON public.profiles FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own profile"
ON public.profiles FOR UPDATE
USING (auth.uid() = user_id);

-- Lessons policies (public read access)
CREATE POLICY "Anyone can view lessons"
ON public.lessons FOR SELECT
USING (true);

-- Exercises policies (public read access)
CREATE POLICY "Anyone can view exercises"
ON public.exercises FOR SELECT
USING (true);

-- Submissions policies (user-specific)
CREATE POLICY "Users can view their own submissions"
ON public.submissions FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own submissions"
ON public.submissions FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own submissions"
ON public.submissions FOR UPDATE
USING (auth.uid() = user_id);

-- User progress policies
CREATE POLICY "Users can view their own progress"
ON public.user_progress FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own progress"
ON public.user_progress FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own progress"
ON public.user_progress FOR UPDATE
USING (auth.uid() = user_id);

-- Create storage bucket for file uploads
INSERT INTO storage.buckets (id, name, public) VALUES ('submissions', 'submissions', false);

-- Storage policies for submissions
CREATE POLICY "Users can upload their own submissions"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'submissions' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their own submissions"
ON storage.objects FOR SELECT
USING (bucket_id = 'submissions' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_profiles_updated_at
BEFORE UPDATE ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_lessons_updated_at
BEFORE UPDATE ON public.lessons
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_submissions_updated_at
BEFORE UPDATE ON public.submissions
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_user_progress_updated_at
BEFORE UPDATE ON public.user_progress
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert sample Grade 8 South African math lessons
INSERT INTO public.lessons (title, description, topic, youtube_url, content, order_index) VALUES
('Introduction to Algebra', 'Learn the basics of algebraic expressions and equations', 'Algebra', 'https://youtube.com/watch?v=example1', 'Understanding variables, coefficients, and basic algebraic operations', 1),
('Linear Equations', 'Solving linear equations in one variable', 'Algebra', 'https://youtube.com/watch?v=example2', 'Step-by-step guide to solving linear equations', 2),
('Geometry: Angles and Lines', 'Understanding different types of angles and line relationships', 'Geometry', 'https://youtube.com/watch?v=example3', 'Acute, obtuse, right angles, parallel and perpendicular lines', 3),
('Fractions and Decimals', 'Converting between fractions and decimals', 'Number Theory', 'https://youtube.com/watch?v=example4', 'Operations with fractions and decimal notation', 4),
('Percentage Calculations', 'Working with percentages in real-life problems', 'Number Theory', 'https://youtube.com/watch?v=example5', 'Calculating percentages, discounts, and interest', 5);

-- Insert sample exercises
INSERT INTO public.exercises (lesson_id, question, answer, explanation, difficulty, order_index) VALUES
((SELECT id FROM public.lessons WHERE title = 'Introduction to Algebra' LIMIT 1), 'Simplify: 3x + 5x', '8x', 'Combine like terms: 3x + 5x = (3+5)x = 8x', 'easy', 1),
((SELECT id FROM public.lessons WHERE title = 'Introduction to Algebra' LIMIT 1), 'If x = 4, what is 2x + 3?', '11', 'Substitute x = 4: 2(4) + 3 = 8 + 3 = 11', 'easy', 2),
((SELECT id FROM public.lessons WHERE title = 'Linear Equations' LIMIT 1), 'Solve: 2x + 7 = 15', 'x = 4', 'Subtract 7 from both sides: 2x = 8, then divide by 2: x = 4', 'medium', 1),
((SELECT id FROM public.lessons WHERE title = 'Percentage Calculations' LIMIT 1), 'What is 25% of 80?', '20', '25% = 25/100 = 0.25, so 0.25 × 80 = 20', 'easy', 1);