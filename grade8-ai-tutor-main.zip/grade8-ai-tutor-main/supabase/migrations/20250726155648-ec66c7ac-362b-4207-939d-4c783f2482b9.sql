-- Insert more complex Grade 8 exercises and update lessons with YouTube videos

-- Update existing lessons with real YouTube video URLs
UPDATE lessons SET 
  youtube_url = 'https://www.youtube.com/watch?v=jxHyzT540Gc',
  content = 'Learn how to solve linear equations step by step. Understand when equations have one solution, infinite solutions, or no solution. Master the distributive property and solving for variables.'
WHERE topic = 'Linear Equations';

UPDATE lessons SET 
  youtube_url = 'https://www.youtube.com/watch?v=WqhlG3Vakw8',
  content = 'Discover the Pythagorean theorem and its applications. Learn to find missing sides in right triangles and solve real-world problems using a² + b² = c².'
WHERE topic = 'Geometry';

UPDATE lessons SET 
  youtube_url = 'https://www.youtube.com/watch?v=8C2oPQ1IE8I',
  content = 'Master converting between fractions, decimals, and percentages. Learn efficient methods and shortcuts for quick conversions in real-world scenarios.'
WHERE topic = 'Fractions and Decimals';

-- Add more complex exercises for Linear Equations
INSERT INTO exercises (lesson_id, question, answer, explanation, difficulty, order_index) VALUES 
((SELECT id FROM lessons WHERE topic = 'Linear Equations' LIMIT 1), 
'Solve for x: 3(2x - 4) = 2(x + 5) + 8', 
'x = 6', 
'First expand both sides: 6x - 12 = 2x + 10 + 8. Simplify the right side: 6x - 12 = 2x + 18. Subtract 2x from both sides: 4x - 12 = 18. Add 12 to both sides: 4x = 30. Divide by 4: x = 6.',
'hard', 3),

((SELECT id FROM lessons WHERE topic = 'Linear Equations' LIMIT 1), 
'If 5x - 3 = 2x + 15, what is the value of 3x + 7?', 
'25', 
'First solve for x: 5x - 3 = 2x + 15. Subtract 2x: 3x - 3 = 15. Add 3: 3x = 18, so x = 6. Then 3x + 7 = 3(6) + 7 = 18 + 7 = 25.',
'hard', 4),

((SELECT id FROM lessons WHERE topic = 'Linear Equations' LIMIT 1), 
'Solve for y: (y + 3)/4 - (y - 1)/6 = 2', 
'y = 9', 
'Find common denominator (12): 3(y + 3)/12 - 2(y - 1)/12 = 2. Simplify: (3y + 9 - 2y + 2)/12 = 2. This gives (y + 11)/12 = 2. Multiply by 12: y + 11 = 24. Subtract 11: y = 9.',
'hard', 5);

-- Add more complex exercises for Geometry  
INSERT INTO exercises (lesson_id, question, answer, explanation, difficulty, order_index) VALUES 
((SELECT id FROM lessons WHERE topic = 'Geometry' LIMIT 1), 
'A ladder is leaning against a wall. The ladder is 13 feet long and the bottom is 5 feet from the wall. How high up the wall does the ladder reach?', 
'12 feet', 
'Use the Pythagorean theorem: a² + b² = c². Here a = 5 feet, c = 13 feet. So 5² + b² = 13². This gives 25 + b² = 169. Therefore b² = 144, and b = 12 feet.',
'hard', 3),

((SELECT id FROM lessons WHERE topic = 'Geometry' LIMIT 1), 
'Find the diagonal of a rectangle with length 15 cm and width 8 cm.', 
'17 cm', 
'The diagonal forms a right triangle with the length and width. Using Pythagorean theorem: d² = 15² + 8² = 225 + 64 = 289. Therefore d = √289 = 17 cm.',
'hard', 4),

((SELECT id FROM lessons WHERE topic = 'Geometry' LIMIT 1), 
'A right triangle has legs of length x and x+7. If the hypotenuse is 13, find x.', 
'x = 5', 
'Using Pythagorean theorem: x² + (x+7)² = 13². Expand: x² + x² + 14x + 49 = 169. Simplify: 2x² + 14x + 49 = 169. Rearrange: 2x² + 14x - 120 = 0. Divide by 2: x² + 7x - 60 = 0. Factor: (x+12)(x-5) = 0. Since x must be positive, x = 5.',
'hard', 5);

-- Add more complex exercises for Fractions and Decimals
INSERT INTO exercises (lesson_id, question, answer, explanation, difficulty, order_index) VALUES 
((SELECT id FROM lessons WHERE topic = 'Fractions and Decimals' LIMIT 1), 
'Calculate: 2⅔ + 1¾ - ⅚', 
'3 7/12', 
'Convert to improper fractions: 8/3 + 7/4 - 5/6. Find LCD (12): 32/12 + 21/12 - 10/12 = 43/12 = 3 7/12.',
'hard', 3),

((SELECT id FROM lessons WHERE topic = 'Fractions and Decimals' LIMIT 1), 
'If 35% of a number is 84, what is 60% of the same number?', 
'144', 
'First find the number: 35% of x = 84, so 0.35x = 84, therefore x = 84 ÷ 0.35 = 240. Now find 60%: 60% of 240 = 0.60 × 240 = 144.',
'hard', 4),

((SELECT id FROM lessons WHERE topic = 'Fractions and Decimals' LIMIT 1), 
'Express 0.375 as a fraction in lowest terms.', 
'3/8', 
'0.375 = 375/1000. Find GCD of 375 and 1000: GCD is 125. Divide both by 125: 375÷125 = 3, 1000÷125 = 8. Therefore 0.375 = 3/8.',
'hard', 5);

-- Add new challenging lesson with complex problems
INSERT INTO lessons (title, description, topic, grade, order_index, youtube_url, content) VALUES 
('Advanced Problem Solving', 
'Complex multi-step problems combining algebra, geometry, and number operations for advanced Grade 8 students.',
'Problem Solving',
8,
4,
'https://www.youtube.com/watch?v=2qdI__L6RBI',
'Learn advanced problem-solving strategies for complex Grade 8 math problems. Master multi-step equations, word problems, and real-world applications combining multiple mathematical concepts.');

-- Add exercises for the new advanced lesson
INSERT INTO exercises (lesson_id, question, answer, explanation, difficulty, order_index) VALUES 
((SELECT id FROM lessons WHERE topic = 'Problem Solving' LIMIT 1), 
'A rectangular garden is 3 times as long as it is wide. If the perimeter is 48 meters, what is the area?', 
'108 square meters', 
'Let width = w, then length = 3w. Perimeter = 2w + 2(3w) = 8w = 48. So w = 6 meters, length = 18 meters. Area = 6 × 18 = 108 square meters.',
'hard', 1),

((SELECT id FROM lessons WHERE topic = 'Problem Solving' LIMIT 1), 
'Sarah has twice as many stickers as Tom. Together they have 45 stickers. If Tom gives Sarah 3 stickers, how many will Sarah have?', 
'33 stickers', 
'Let Tom have x stickers, Sarah has 2x. Total: x + 2x = 45, so 3x = 45, x = 15. Tom has 15, Sarah has 30. After Tom gives 3: Tom has 12, Sarah has 33.',
'hard', 2),

((SELECT id FROM lessons WHERE topic = 'Problem Solving' LIMIT 1), 
'A store marks up items by 40% above cost. If an item sells for $91, what was the cost price?', 
'$65', 
'Let cost price = C. Selling price = C + 40% of C = C + 0.4C = 1.4C = 91. Therefore C = 91 ÷ 1.4 = $65.',
'hard', 3),

((SELECT id FROM lessons WHERE topic = 'Problem Solving' LIMIT 1), 
'In a class of 32 students, the ratio of boys to girls is 3:5. How many more girls than boys are there?', 
'8 more girls', 
'Ratio 3:5 means 3+5=8 parts total. Each part = 32÷8 = 4 students. Boys = 3×4 = 12, Girls = 5×4 = 20. Difference = 20-12 = 8 more girls.',
'hard', 4);